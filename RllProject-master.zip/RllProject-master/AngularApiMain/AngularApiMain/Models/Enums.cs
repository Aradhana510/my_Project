﻿namespace AngularApiMain.Models
{
    public enum OrderStatus
    {
        Active,
        Completed,
        Cancelled

    }
}
