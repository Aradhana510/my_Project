﻿using System.ComponentModel.DataAnnotations;

namespace AngularApiMain.Models
{
    public class OrderReviewAndRatingUpdatecs
    {
        
    }
}
